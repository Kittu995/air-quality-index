import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, precision_recall_fscore_support
from aqi_cpcb import CATEGORIES


def regression_metrics(y, p):
    mse = mean_squared_error(y, p)
    return {"MAE": float(mean_absolute_error(y, p)), "MSE": float(mse), "RMSE": float(np.sqrt(mse)), "R2": float(r2_score(y, p))}


def to_cat(a):
    edges = [c[1] for c in CATEGORIES]
    return np.array([next((i for i, e in enumerate(edges) if v <= e), len(edges) - 1) for v in a])


def category_metrics(y, p):
    yt, yp = to_cat(y), to_cat(p)
    pr, rc, f1, _ = precision_recall_fscore_support(yt, yp, average="weighted", zero_division=0)
    return {"accuracy": float(accuracy_score(yt, yp)), "precision": float(pr), "recall": float(rc), "f1": float(f1)}


def plot_pred_vs_actual(y, p, path, title):
    plt.figure(figsize=(5, 5)); plt.scatter(y, p, s=6, alpha=.4, color="#1d6fa5")
    m = [min(y), max(y)]; plt.plot(m, m, "--", color="#13a87b"); plt.xlabel("Actual AQI"); plt.ylabel("Predicted AQI")
    plt.title(title); plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()


def plot_importance(names, vals, path):
    o = np.argsort(vals); plt.figure(figsize=(6, 4)); plt.barh(np.array(names)[o], np.array(vals)[o], color="#13a87b")
    plt.xlabel("Mean |SHAP value| (AQI points)"); plt.title("Feature importance"); plt.tight_layout(); plt.savefig(path, dpi=130); plt.close()
