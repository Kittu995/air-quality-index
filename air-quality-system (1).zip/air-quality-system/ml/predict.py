"""Loads the saved model and produces a prediction with SHAP explanation."""
import os, joblib, numpy as np, shap
from aqi_cpcb import compute_aqi, category

MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "model", "aqi_model.joblib")
LABELS = {"pm25": "PM2.5", "pm10": "PM10", "co": "CO", "no2": "NO2", "so2": "SO2", "o3": "O3", "temperature": "temperature",
          "humidity": "humidity", "wind_speed": "wind speed", "traffic_density": "traffic density", "month": "time of year", "dayofweek": "day of week"}
_cache = {}


def load():
    if "b" not in _cache:
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError("Model not trained yet. Run: python ml/train_model.py")
        b = joblib.load(MODEL_PATH)
        b["explainer"] = shap.TreeExplainer(b["model"])
        _cache["b"] = b
    return _cache["b"]


def predict(inputs):
    """inputs: pm25, pm10, co, no2, so2, o3, temperature, humidity, wind_speed, traffic_density, month, dayofweek"""
    b = load()
    X = np.array([[float(inputs[f]) for f in b["features"]]])
    pred = float(np.clip(b["model"].predict(X)[0], 0, 500))
    cur, dom, _ = compute_aqi(inputs)
    out = {"predicted_aqi": round(pred), "current_aqi": cur, "model": b["model_name"], "category": category(pred),
           "simulated_training_data": b["is_simulated"], "uncertainty": None}
    if b["model_name"] == "RandomForest":  # spread across trees: only RF supports this
        per_tree = np.array([t.predict(X)[0] for t in b["model"].estimators_])
        out["uncertainty"] = {"low": round(float(np.percentile(per_tree, 10))), "high": round(float(np.percentile(per_tree, 90))),
                              "note": "10th-90th percentile of individual trees; not a statistical guarantee"}
    sv = b["explainer"].shap_values(X)[0]
    contribs = sorted(({"feature": f, "label": LABELS[f], "value": float(X[0][i]), "effect": round(float(sv[i]), 1)}
                       for i, f in enumerate(b["features"])), key=lambda d: -abs(d["effect"]))
    for c in contribs:
        c["text"] = f"{c['label']} ({c['value']:g}) {'raises' if c['effect'] > 0 else 'lowers'} the forecast by about {abs(c['effect']):.0f} AQI points"
    out["explanation"] = contribs
    out["base_value"] = round(float(np.ravel(b["explainer"].expected_value)[0]), 1)
    return out
