"""Creates a SIMULATED demo dataset (ml/dataset/air_quality.csv).
It is NOT real measurement data. Every row has is_simulated=1 and the website
labels it as sample data. For real data, build a CSV with the same columns
(see README) from CPCB / OpenAQ / Open-Meteo and put it in ml/dataset/.
Station positions are placed on a ring around DEMO_CENTER and are also simulated."""
import math, os, numpy as np, pandas as pd
from aqi_cpcb import compute_aqi

LAT = float(os.getenv("DEMO_CENTER_LAT", 12.9716))
LON = float(os.getenv("DEMO_CENTER_LON", 77.5946))
STATIONS = [("Sample Station A (Traffic)", 1.25, 1.5), ("Sample Station B (Industrial)", 1.1, 0.9),
            ("Sample Station C (Residential)", 0.75, 0.6), ("Sample Station D (Construction)", 1.3, 0.8),
            ("Sample Station E (Park)", 0.55, 0.3), ("Sample Station F (Market)", 1.0, 1.3),
            ("Sample Station G (Highway)", 1.2, 1.8), ("Sample Station H (Campus)", 0.65, 0.5)]
rng = np.random.RandomState(42)
days = pd.date_range("2023-01-01", "2025-12-31", freq="D")
rows = []
for si, (name, pf, tf) in enumerate(STATIONS):
    ang = 2 * math.pi * si / len(STATIONS)
    lat, lon = LAT + 0.06 * math.sin(ang), LON + 0.06 * math.cos(ang)
    ar = 0.0
    for d in days:
        doy = d.dayofyear
        winter = 0.5 + 0.5 * math.cos(2 * math.pi * (doy - 15) / 365)       # peak in January
        temp = 26 - 6 * winter + 3 * math.sin(2 * math.pi * (doy - 100) / 365) + rng.normal(0, 1.5)
        hum = np.clip(55 + 15 * math.sin(2 * math.pi * (doy - 170) / 365) + rng.normal(0, 8), 20, 98)
        wind = max(0.5, rng.gamma(3, 2.2) - 2 * winter)
        traffic = np.clip(tf * (45 + 25 * (d.dayofweek < 5)) + rng.normal(0, 8), 5, 100)
        ar = 0.7 * ar + rng.normal(0, 0.18)
        load = pf * (0.7 + 0.9 * winter) * (1 - 0.03 * min(wind, 12)) * (1 + 0.004 * (traffic - 50)) * math.exp(ar)
        pm25 = max(5, 55 * load + rng.normal(0, 6))
        pm10 = max(10, pm25 * rng.uniform(1.6, 2.1))
        no2 = max(5, 28 * load * (0.6 + 0.01 * traffic) + rng.normal(0, 4))
        so2 = max(2, 11 * pf * (0.8 + 0.4 * winter) + rng.normal(0, 2))
        co = max(0.2, 0.7 * load * (0.7 + 0.008 * traffic) + rng.normal(0, 0.1))
        o3 = max(5, 38 + 0.9 * (temp - 24) - 0.1 * pm25 + rng.normal(0, 6))
        r = dict(pm25=pm25, pm10=pm10, co=co, no2=no2, so2=so2, o3=o3)
        aqi, _, _ = compute_aqi(r)
        rows.append(dict(station=name, datetime=d.strftime("%Y-%m-%d %H:%M:%S"), lat=round(lat, 5), lon=round(lon, 5),
                         **{k: round(v, 2) for k, v in r.items()}, temperature=round(temp, 1), humidity=round(hum, 1),
                         wind_speed=round(wind, 1), traffic_density=round(traffic, 1), aqi=aqi,
                         source="Simulated sample dataset", is_simulated=1))
pd.DataFrame(rows).to_csv(os.path.join(os.path.dirname(__file__), "dataset", "air_quality.csv"), index=False)
print(f"Wrote {len(rows)} simulated rows for {len(STATIONS)} stations")
