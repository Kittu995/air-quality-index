"""Indian CPCB AQI (sub-index interpolation, overall = max sub-index).
PM2.5, PM10, NO2, SO2, O3 in ug/m3; CO in mg/m3. Needs PM2.5 or PM10 + >=3 pollutants."""
BANDS = [(0, 50), (51, 100), (101, 200), (201, 300), (301, 400), (401, 500)]
BP = {
    "pm25": [(0, 30), (31, 60), (61, 90), (91, 120), (121, 250), (251, 380)],
    "pm10": [(0, 50), (51, 100), (101, 250), (251, 350), (351, 430), (431, 600)],
    "no2": [(0, 40), (41, 80), (81, 180), (181, 280), (281, 400), (401, 600)],
    "o3": [(0, 50), (51, 100), (101, 168), (169, 208), (209, 748), (749, 1000)],
    "co": [(0, 1.0), (1.1, 2.0), (2.1, 10), (10.1, 17), (17.1, 34), (34.1, 50)],
    "so2": [(0, 40), (41, 80), (81, 380), (381, 800), (801, 1600), (1601, 2000)],
}
CATEGORIES = [
    ("Good", 50, "#1f9d55", "Minimal", "No major pollution warning."),
    ("Satisfactory", 100, "#9bc53d", "Low", "Unusually sensitive people may notice minor discomfort."),
    ("Moderate", 200, "#f2b035", "Moderate", "General precaution: people with lung/heart disease, children and older adults should limit prolonged exertion."),
    ("Poor", 300, "#ee7d2f", "High", "Reduce prolonged outdoor exposure."),
    ("Very Poor", 400, "#d0342c", "Very high", "Avoid unnecessary outdoor activities."),
    ("Severe", 500, "#7b2d8e", "Severe", "URGENT: stay indoors, keep windows closed, follow authority advice."),
]


def category(aqi):
    for name, mx, color, risk, advice in CATEGORIES:
        if aqi <= mx:
            return {"name": name, "color": color, "risk": risk, "advice": advice}
    n = CATEGORIES[-1]
    return {"name": n[0], "color": n[2], "risk": n[3], "advice": n[4]}


def sub_index(key, v):
    if v is None or v != v:
        return None
    bps = BP[key]
    i = next((k for k, (_, hi) in enumerate(bps) if v <= hi), len(bps) - 1)
    (clo, chi), (ilo, ihi) = bps[i], BANDS[i]
    v = min(max(v, clo), chi)
    return round((ihi - ilo) / (chi - clo) * (v - clo) + ilo)


def compute_aqi(row):
    """row: mapping with pm25, pm10, co, no2, so2, o3. Returns (aqi, dominant, subs) or (None, None, {})."""
    subs = {k: s for k in BP if (s := sub_index(k, row.get(k))) is not None}
    if len(subs) < 3 or ("pm25" not in subs and "pm10" not in subs):
        return None, None, {}
    dom = max(subs, key=subs.get)
    return subs[dom], dom, subs
