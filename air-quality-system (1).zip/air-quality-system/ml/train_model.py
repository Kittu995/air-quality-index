"""Train and compare Random Forest and XGBoost, then save the best with Joblib.
Target = next-day AQI of the same station. Time-based split (no shuffling) avoids leakage.
Usage: python generate_sample_dataset.py   (only if you have no real CSV)
       python train_model.py [path/to/air_quality.csv]"""
import json, os, sys, joblib, numpy as np, pandas as pd, shap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import mutual_info_regression
from xgboost import XGBRegressor
from aqi_cpcb import compute_aqi
from evaluation import regression_metrics, category_metrics, plot_pred_vs_actual, plot_importance

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "model")
POLL = ["pm25", "pm10", "co", "no2", "so2", "o3"]
CAND = POLL + ["temperature", "humidity", "wind_speed", "traffic_density", "month", "dayofweek"]

path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "dataset", "air_quality.csv")
df = pd.read_csv(path)
print(f"Loaded {len(df)} rows from {path}")

# 1) Cleaning: types, duplicates, missing values
df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
df = df.dropna(subset=["datetime", "station"]).drop_duplicates(subset=["station", "datetime"]).sort_values(["station", "datetime"])
num = POLL + ["temperature", "humidity", "wind_speed", "traffic_density"]
for c in num:
    df[c] = pd.to_numeric(df.get(c), errors="coerce")
df[num] = df.groupby("station")[num].transform(lambda s: s.interpolate(limit=3, limit_direction="both"))
df[num] = df[num].fillna(df[num].median())
miss = df["aqi"].isna() if "aqi" in df else pd.Series(True, index=df.index)
if "aqi" not in df:
    df["aqi"] = np.nan
df.loc[miss, "aqi"] = [compute_aqi(r)[0] for r in df.loc[miss, POLL].to_dict("records")]
df = df.dropna(subset=["aqi"])
df["month"], df["dayofweek"] = df["datetime"].dt.month, df["datetime"].dt.dayofweek

# 2) EDA
df[num + ["aqi"]].describe().T.to_csv(os.path.join(OUT, "eda_summary.csv"))
plt.figure(figsize=(6, 4)); plt.hist(df["aqi"], bins=40, color="#1d6fa5"); plt.xlabel("AQI"); plt.title("AQI distribution")
plt.tight_layout(); plt.savefig(os.path.join(OUT, "eda_aqi_hist.png"), dpi=130); plt.close()
corr = df[num + ["aqi"]].corr()
plt.figure(figsize=(7, 6)); plt.imshow(corr, cmap="RdBu_r", vmin=-1, vmax=1); plt.colorbar()
plt.xticks(range(len(corr)), corr.columns, rotation=60, ha="right"); plt.yticks(range(len(corr)), corr.columns)
plt.title("Correlation matrix"); plt.tight_layout(); plt.savefig(os.path.join(OUT, "eda_corr.png"), dpi=130); plt.close()

# 3) Target: next-day AQI per station; time-based split
df["target"] = df.groupby("station")["aqi"].shift(-1)
df = df.dropna(subset=["target"]).sort_values("datetime")
cut = df["datetime"].quantile(0.8)
tr, te = df[df["datetime"] <= cut], df[df["datetime"] > cut]
print(f"Train {len(tr)} rows (to {cut.date()}), test {len(te)} rows")

# 4) Feature selection by mutual information (trees need no scaling)
mi = pd.Series(mutual_info_regression(tr[CAND], tr["target"], random_state=0), index=CAND)
FEATURES = [f for f in CAND if mi[f] >= 0.05 * mi.max() or f in ("pm25", "pm10")]
print("Selected features:", FEATURES)

models = {
    "RandomForest": RandomForestRegressor(n_estimators=300, min_samples_leaf=2, n_jobs=-1, random_state=42),
    "XGBoost": XGBRegressor(n_estimators=400, learning_rate=0.05, max_depth=6, subsample=0.8, colsample_bytree=0.9, random_state=42),
}
results, preds = {}, {}
for name, m in models.items():
    m.fit(tr[FEATURES], tr["target"])
    p = m.predict(te[FEATURES]); preds[name] = p
    results[name] = {**regression_metrics(te["target"], p), **category_metrics(te["target"], p)}
    print(name, {k: round(v, 3) for k, v in results[name].items()})
best = min(results, key=lambda k: results[k]["RMSE"])
print("Best model (lowest RMSE):", best)

# 5) SHAP on the best model
sample = te[FEATURES].sample(min(500, len(te)), random_state=0)
sv = shap.TreeExplainer(models[best]).shap_values(sample)
imp = dict(zip(FEATURES, np.abs(sv).mean(axis=0).round(4).tolist()))
plot_importance(list(imp), list(imp.values()), os.path.join(OUT, "shap_importance.png"))
plot_pred_vs_actual(te["target"].values, preds[best], os.path.join(OUT, "pred_vs_actual.png"), f"{best}: predicted vs actual")

joblib.dump({"model": models[best], "rf": models["RandomForest"], "model_name": best, "features": FEATURES,
             "is_simulated": bool(df.get("is_simulated", pd.Series([0])).max()), "trained_until": str(cut.date())},
            os.path.join(OUT, "aqi_model.joblib"))
json.dump({"best": best, "metrics": results, "features": FEATURES, "shap_importance": imp, "train_rows": len(tr),
           "test_rows": len(te), "simulated_training_data": bool(df.get("is_simulated", pd.Series([0])).max())},
          open(os.path.join(OUT, "metrics.json"), "w"), indent=2)
print("Saved model + metrics to", OUT)
