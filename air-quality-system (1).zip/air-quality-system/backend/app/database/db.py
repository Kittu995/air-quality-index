import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

load_dotenv(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".env"))
# MySQL:  mysql+pymysql://user:password@localhost:3306/air_quality   |  quick demo: sqlite:///./airquality.db
URL = os.getenv("DATABASE_URL", "sqlite:///./airquality.db")
engine = create_engine(URL, pool_pre_ping=True,
                       connect_args={"check_same_thread": False} if URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
