"""Load a CSV (default ml/dataset/air_quality.csv) into MySQL/SQLite, then build alerts and recommendations.
Run from backend/:  python -m app.database.seed [path/to/csv]"""
import os, sys
import pandas as pd
from app.database.db import engine, SessionLocal, Base
from app.models.tables import Location, AirQualityRecord, WeatherRecord, PollutionAlert, MitigationRecommendation
from app.services.ml_service import compute_aqi, category
from app.services import recommendations

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "ml", "dataset", "air_quality.csv")
POLL = ["pm25", "pm10", "co", "no2", "so2", "o3"]


def msg(cat, name, aqi):
    return f"{cat['name']} air at {name} (AQI {aqi}). {cat['advice']}"


def main():
    Base.metadata.drop_all(engine); Base.metadata.create_all(engine)
    df = pd.read_csv(path, parse_dates=["datetime"]).drop_duplicates(["station", "datetime"])
    df["is_simulated"] = (df["is_simulated"].fillna(0) if "is_simulated" in df else 0)
    df["is_simulated"] = df["is_simulated"].astype(bool)
    s = SessionLocal()
    ids = {}
    for st, g in df.groupby("station"):
        loc = Location(name=st, latitude=float(g["lat"].iloc[0]), longitude=float(g["lon"].iloc[0]), is_simulated=bool(g["is_simulated"].iloc[0]))
        s.add(loc); s.flush(); ids[st] = loc.id
    aq, wx = [], []
    for r in df.to_dict("records"):
        aqi, dom, _ = compute_aqi(r)
        if r.get("aqi") == r.get("aqi") and pd.notna(r.get("aqi")):
            aqi = int(r["aqi"])
        lid = ids[r["station"]]
        aq.append(dict(location_id=lid, recorded_at=r["datetime"], **{k: (None if pd.isna(r[k]) else float(r[k])) for k in POLL},
                       traffic_density=r.get("traffic_density"), aqi=aqi, dominant_pollutant=dom, source=r["source"], is_simulated=r["is_simulated"]))
        wx.append(dict(location_id=lid, recorded_at=r["datetime"], temperature=r.get("temperature"), humidity=r.get("humidity"),
                       wind_speed=r.get("wind_speed"), source=r["source"], is_simulated=r["is_simulated"]))
    for i in range(0, len(aq), 2000):
        s.bulk_insert_mappings(AirQualityRecord, aq[i:i + 2000]); s.bulk_insert_mappings(WeatherRecord, wx[i:i + 2000])
    s.commit()
    # Alerts: last 14 days where AQI is above Satisfactory. Recommendations: latest record per location.
    for st, lid in ids.items():
        recs = s.query(AirQualityRecord).filter_by(location_id=lid).order_by(AirQualityRecord.recorded_at.desc()).limit(14).all()
        for r in recs:
            if r.aqi and r.aqi > 100:
                c = category(r.aqi)
                s.add(PollutionAlert(location_id=lid, aqi=r.aqi, category=c["name"], message=msg(c, st, r.aqi), record_time=r.recorded_at, is_simulated=r.is_simulated))
        last = recs[0]
        for rec in recommendations.build({k: getattr(last, k) for k in POLL + ["traffic_density"]}):
            s.add(MitigationRecommendation(location_id=lid, issue=rec["issue"], action=rec["action"], priority=rec["priority"],
                                           expected_benefit=rec["expected_benefit"], origin=rec["origin"]))
    s.commit()
    print(f"Seeded {len(ids)} locations, {len(aq)} records from {path}")


if __name__ == "__main__":
    main()
