from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Text, Index
from app.database.db import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default="viewer")
    created_at = Column(DateTime, default=datetime.utcnow)


class Location(Base):
    __tablename__ = "locations"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), unique=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    is_simulated = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class AirQualityRecord(Base):
    """Observed (or clearly flagged simulated) measurements. Never holds model output."""
    __tablename__ = "air_quality_records"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    recorded_at = Column(DateTime, nullable=False)
    pm25 = Column(Float); pm10 = Column(Float); co = Column(Float)
    no2 = Column(Float); so2 = Column(Float); o3 = Column(Float)
    traffic_density = Column(Float)
    aqi = Column(Integer)
    dominant_pollutant = Column(String(10))
    source = Column(String(120), nullable=False)
    is_simulated = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    __table_args__ = (Index("ix_aq_loc_time", "location_id", "recorded_at"),)


class WeatherRecord(Base):
    __tablename__ = "weather_records"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    recorded_at = Column(DateTime, nullable=False)
    temperature = Column(Float); humidity = Column(Float); wind_speed = Column(Float)
    source = Column(String(120), nullable=False)
    is_simulated = Column(Boolean, default=False)
    __table_args__ = (Index("ix_w_loc_time", "location_id", "recorded_at"),)


class AqiPrediction(Base):
    """Model outputs, stored separately from observations."""
    __tablename__ = "aqi_predictions"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="SET NULL"))
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    input_json = Column(Text, nullable=False)
    predicted_aqi = Column(Integer, nullable=False)
    current_aqi = Column(Integer)
    category = Column(String(20))
    model_name = Column(String(40))
    uncertainty_low = Column(Integer); uncertainty_high = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)


class PollutionAlert(Base):
    __tablename__ = "pollution_alerts"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    aqi = Column(Integer, nullable=False)
    category = Column(String(20), nullable=False)
    message = Column(Text, nullable=False)
    record_time = Column(DateTime, nullable=False)
    is_simulated = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class MitigationRecommendation(Base):
    __tablename__ = "mitigation_recommendations"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    issue = Column(String(150), nullable=False)
    action = Column(Text, nullable=False)
    priority = Column(String(10), nullable=False)
    expected_benefit = Column(Text)
    origin = Column(String(60), default="AI-generated suggestion (not verified)")
    created_at = Column(DateTime, default=datetime.utcnow)
