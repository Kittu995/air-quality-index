import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.database.db import Base, engine
from app.models import tables  # noqa: F401  (registers tables)
from app.routes import data, prediction, alerts, reports

app = FastAPI(title="Air Quality Prediction and Urban Pollution Mitigation API", version="1.0")
origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": "Internal server error. See the server log."})


@app.get("/api/health")
def health():
    return {"status": "ok"}


for r in (data.router, prediction.router, alerts.router, reports.router):
    app.include_router(r)
