import csv, io, os
from datetime import datetime
from typing import Optional
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import and_
from sqlalchemy.orm import Session
from app.database.db import get_db
from app.models.tables import Location, AirQualityRecord as AQ, WeatherRecord as W
from app.services.ml_service import category
from app.services.queries import get_location, latest, last_n, POLL

router = APIRouter(prefix="/api")
HOTSPOT_AQI = int(os.getenv("HOTSPOT_AQI", 200))


@router.get("/locations")
def locations(db: Session = Depends(get_db)):
    return [dict(id=l.id, name=l.name, latitude=l.latitude, longitude=l.longitude, is_simulated=l.is_simulated)
            for l in db.query(Location).order_by(Location.name)]


@router.get("/dashboard")
def dashboard(location: Optional[str] = None, db: Session = Depends(get_db)):
    loc = get_location(db, location)
    last = latest(db, loc.id)
    if not last:
        raise HTTPException(404, "No observations for this location")
    wx = db.query(W).filter_by(location_id=loc.id).order_by(W.recorded_at.desc()).first()
    trend = last_n(db, loc.id, 30)
    return {
        "location": loc.name, "source": last.source, "simulated": bool(last.is_simulated),
        "updatedAt": last.recorded_at.isoformat(), "aqi": last.aqi, "category": category(last.aqi),
        "current": {k: getattr(last, k) for k in POLL},
        "weather": {"temperature": wx.temperature, "humidity": wx.humidity, "windSpeed": wx.wind_speed, "condition": "Not recorded"} if wx else None,
        "trend": [{"label": r.recorded_at.strftime("%d %b"), "aqi": r.aqi, "pm25": r.pm25, "pm10": r.pm10} for r in trend],
        "weekly": [{"label": r.recorded_at.strftime("%a %d"), "aqi": r.aqi} for r in trend[-7:]],
    }


SORTABLE = {"recorded_at": AQ.recorded_at, "aqi": AQ.aqi, "location": Location.name, **{p: getattr(AQ, p) for p in POLL}}


def records_query(db, location, start, end, pollutant, min_value, sort_by, order):
    q = db.query(AQ, Location.name).join(Location, Location.id == AQ.location_id)
    if location:
        q = q.filter(Location.name == location)
    if start:
        q = q.filter(AQ.recorded_at >= datetime.fromisoformat(start))
    if end:
        q = q.filter(AQ.recorded_at <= datetime.fromisoformat(end + "T23:59:59" if len(end) == 10 else end))
    if pollutant in POLL and min_value is not None:
        q = q.filter(getattr(AQ, pollutant) >= min_value)
    col = SORTABLE.get(sort_by, AQ.recorded_at)
    return q.order_by(col.asc() if order == "asc" else col.desc())


def row_dict(r, name):
    return {"location": name, "recorded_at": r.recorded_at.isoformat(sep=" "), "aqi": r.aqi, "category": category(r.aqi)["name"] if r.aqi else None,
            **{p: getattr(r, p) for p in POLL}, "source": r.source, "simulated": bool(r.is_simulated)}


@router.get("/air-quality")
def air_quality(location: Optional[str] = None, start: Optional[str] = None, end: Optional[str] = None, pollutant: Optional[str] = None,
                min_value: Optional[float] = None, sort_by: str = "recorded_at", order: str = "desc", limit: int = 50, offset: int = 0,
                db: Session = Depends(get_db)):
    try:
        q = records_query(db, location, start, end, pollutant, min_value, sort_by, order)
    except ValueError:
        raise HTTPException(422, "Dates must look like 2025-01-31")
    limit = max(1, min(limit, 500))
    return {"total": q.count(), "rows": [row_dict(r, n) for r, n in q.offset(offset).limit(limit)]}


@router.get("/air-quality/csv")
def air_quality_csv(location: Optional[str] = None, start: Optional[str] = None, end: Optional[str] = None, pollutant: Optional[str] = None,
                    min_value: Optional[float] = None, sort_by: str = "recorded_at", order: str = "desc", db: Session = Depends(get_db)):
    rows = [row_dict(r, n) for r, n in records_query(db, location, start, end, pollutant, min_value, sort_by, order).limit(50000)]
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(rows[0]) if rows else ["location"])
    w.writeheader(); w.writerows(rows)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=air_quality_records.csv"})


@router.get("/analytics")
def analytics(location: Optional[str] = None, start: Optional[str] = None, end: Optional[str] = None, granularity: str = "daily", db: Session = Depends(get_db)):
    rule, fmt = {"daily": ("D", "%Y-%m-%d"), "weekly": ("W", "%Y-%m-%d"), "monthly": ("MS", "%b %Y"), "yearly": ("YS", "%Y")}.get(granularity, ("D", "%Y-%m-%d"))
    q = (db.query(AQ.recorded_at, AQ.aqi, AQ.pm25, AQ.pm10, AQ.co, AQ.no2, AQ.so2, AQ.o3, W.temperature, W.humidity, W.wind_speed, Location.name.label("location"))
         .join(Location, Location.id == AQ.location_id)
         .outerjoin(W, and_(W.location_id == AQ.location_id, W.recorded_at == AQ.recorded_at)))
    if start:
        q = q.filter(AQ.recorded_at >= datetime.fromisoformat(start))
    if end:
        q = q.filter(AQ.recorded_at <= datetime.fromisoformat(end + "T23:59:59"))
    df = pd.DataFrame([r._asdict() for r in q.all()])
    if df.empty:
        return {"empty": True}
    sub = df[df["location"] == location] if location else df
    if sub.empty:
        return {"empty": True}
    s = sub.set_index("recorded_at")[["aqi", "pm25", "pm10"]].resample(rule).mean().dropna().round(1)
    scatter = {}
    for col in ("temperature", "humidity", "wind_speed"):
        d = sub.dropna(subset=[col, "aqi"])
        d = d.sample(min(400, len(d)), random_state=0) if len(d) else d
        scatter[col] = [{"x": float(a), "y": float(b)} for a, b in zip(d[col], d["aqi"])]
    return {"empty": False, "granularity": granularity, "series": [{"label": i.strftime(fmt), **row} for i, row in zip(s.index, s.to_dict("records"))],
            "pollutants": {p: round(float(sub[p].mean()), 2) for p in ("pm25", "pm10", "co", "no2", "so2", "o3")},
            "scatter": scatter, "locations": [{"location": k, "aqi": round(float(v), 1)} for k, v in df.groupby("location")["aqi"].mean().items()]}


@router.get("/hotspots")
def hotspots(db: Session = Depends(get_db)):
    out = []
    for loc in db.query(Location).all():
        r = latest(db, loc.id)
        if not r:
            continue
        c = category(r.aqi)
        out.append({"location": loc.name, "latitude": loc.latitude, "longitude": loc.longitude, "aqi": r.aqi, "pm25": r.pm25, "pm10": r.pm10,
                    "category": c["name"], "color": c["color"], "recorded_at": r.recorded_at.isoformat(sep=" "), "source": r.source,
                    "simulated": bool(r.is_simulated), "is_hotspot": (r.aqi or 0) >= HOTSPOT_AQI})
    return {"threshold": HOTSPOT_AQI, "locations": sorted(out, key=lambda d: -(d["aqi"] or 0))}
