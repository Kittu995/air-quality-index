import io
from datetime import datetime
from typing import Optional
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from sqlalchemy.orm import Session
from app.database.db import get_db
from app.models.tables import Location
from app.services import recommendations
from app.services.ml_service import category
from app.services.queries import get_location, latest, last_n, POLL
from app.routes.data import hotspots

router = APIRouter(prefix="/api")
PROJECT = "Air Quality Prediction and Urban Pollution Mitigation System"


def collect(db, rtype, location):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    if rtype == "hotspot":
        h = hotspots(db)
        return {"title": "Pollution Hotspot Report", "location": "All locations", "generated": now,
                "summary": [("Hotspot threshold (AQI)", h["threshold"]), ("Hotspots", sum(x["is_hotspot"] for x in h["locations"]))],
                "table": [["Location", "AQI", "Category", "PM2.5", "PM10", "Hotspot", "Source"]] +
                         [[x["location"], x["aqi"], x["category"], x["pm25"], x["pm10"], "Yes" if x["is_hotspot"] else "No", x["source"]] for x in h["locations"]],
                "chart": ([x["location"].replace("Sample Station ", "") for x in h["locations"]], [x["aqi"] for x in h["locations"]], "AQI by location"),
                "recs": [], "simulated": any(x["simulated"] for x in h["locations"])}
    loc = get_location(db, location)
    last = latest(db, loc.id)
    if not last:
        raise HTTPException(404, "No observations for this location")
    n = 30 if rtype == "monthly" else 14
    rows = last_n(db, loc.id, n)
    aqis = [r.aqi for r in rows if r.aqi]
    c = category(last.aqi)
    summary = [("Latest AQI", last.aqi), ("Category", c["name"]), ("Risk level", c["risk"]), ("Recorded", last.recorded_at.strftime("%Y-%m-%d %H:%M")), ("Source", last.source)]
    if rtype == "monthly":
        summary += [("Mean AQI (30 records)", round(sum(aqis) / len(aqis), 1)), ("Max AQI", max(aqis)), ("Min AQI", min(aqis))]
    return {"title": "Monthly Pollution Report" if rtype == "monthly" else "AQI Report", "location": loc.name, "generated": now, "summary": summary,
            "table": [["Pollutant", "Value", "Unit"]] + [[l, getattr(last, k), u] for k, l, u in
                      [("pm25", "PM2.5", "ug/m3"), ("pm10", "PM10", "ug/m3"), ("co", "CO", "mg/m3"), ("no2", "NO2", "ug/m3"), ("so2", "SO2", "ug/m3"), ("o3", "O3", "ug/m3")]],
            "chart": ([r.recorded_at.strftime("%d %b") for r in rows], [r.aqi for r in rows], f"AQI trend: {loc.name}"),
            "recs": recommendations.build({k: getattr(last, k) for k in POLL + ["traffic_density"]}), "simulated": bool(last.is_simulated)}


@router.get("/reports")
def report(type: str = "aqi", location: Optional[str] = None, db: Session = Depends(get_db)):
    if type not in ("aqi", "hotspot", "monthly"):
        raise HTTPException(422, "type must be aqi, hotspot or monthly")
    return collect(db, type, location)


@router.get("/reports/pdf")
def report_pdf(type: str = "aqi", location: Optional[str] = None, db: Session = Depends(get_db)):
    d = report(type, location, db)
    st = getSampleStyleSheet()
    fig, ax = plt.subplots(figsize=(7, 3)); x, y, t = d["chart"]
    (ax.bar if type == "hotspot" else ax.plot)(x, y, **({"color": "#13a87b"} if type == "hotspot" else {"color": "#1d6fa5", "marker": "o"}))
    ax.set_title(t); ax.set_ylabel("AQI"); plt.xticks(rotation=45, ha="right"); fig.tight_layout()
    img = io.BytesIO(); fig.savefig(img, format="png", dpi=120); plt.close(fig); img.seek(0)
    el = [Paragraph(PROJECT, st["Title"]), Paragraph(d["title"], st["Heading2"]),
          Paragraph(f"Location: {d['location']} &nbsp;|&nbsp; Generated: {d['generated']}", st["Normal"])]
    if d["simulated"]:
        el.append(Paragraph("<b>NOTE: contains simulated sample data, not live measurements.</b>", st["Normal"]))
    el += [Spacer(1, 8), Table([[str(a), str(b)] for a, b in d["summary"]], colWidths=[6 * cm, 10 * cm]), Spacer(1, 8), Image(img, width=16 * cm, height=6.8 * cm), Spacer(1, 8)]
    tb = Table([[str(c) for c in r] for r in d["table"]], repeatRows=1)
    tb.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b2545")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                            ("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 8)]))
    el.append(tb)
    if d["recs"]:
        el += [Spacer(1, 10), Paragraph("Mitigation recommendations (AI-generated suggestions, not verified interventions)", st["Heading3"])]
        el += [Paragraph(f"<b>[{r['priority']}] {r['issue']}</b>: {r['action']}", st["Normal"]) for r in d["recs"]]
    buf = io.BytesIO(); SimpleDocTemplate(buf, pagesize=A4, title=d["title"]).build(el)
    return Response(buf.getvalue(), media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename={type}_report.pdf"})
