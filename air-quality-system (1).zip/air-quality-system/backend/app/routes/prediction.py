import json
import os
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.db import get_db
from app.models.tables import Location, AqiPrediction
from app.schemas.predict import PredictIn
from app.services.ml_service import ml_predict
from app.services import recommendations

router = APIRouter(prefix="/api")
METRICS = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "ml", "model", "metrics.json"))


@router.post("/predict")
def predict(body: PredictIn, db: Session = Depends(get_db)):
    now = datetime.now()
    inputs = body.model_dump(exclude={"location"})
    inputs.update(month=now.month, dayofweek=now.weekday())
    try:
        res = ml_predict.predict(inputs)
    except FileNotFoundError as e:
        raise HTTPException(503, str(e))
    loc = db.query(Location).filter_by(name=body.location).first() if body.location else None
    unc = res["uncertainty"]
    db.add(AqiPrediction(location_id=loc.id if loc else None, input_json=json.dumps(inputs), predicted_aqi=res["predicted_aqi"],
                         current_aqi=res["current_aqi"], category=res["category"]["name"], model_name=res["model"],
                         uncertainty_low=unc["low"] if unc else None, uncertainty_high=unc["high"] if unc else None))
    db.commit()
    res["recommendations"] = recommendations.build(inputs)
    if os.path.exists(METRICS):
        m = json.load(open(METRICS))
        res["global_importance"] = m["shap_importance"]
        res["model_metrics"] = m["metrics"][m["best"]]
    return res


@router.get("/predictions")
def predictions(limit: int = 50, db: Session = Depends(get_db)):
    rows = db.query(AqiPrediction, Location.name).outerjoin(Location, Location.id == AqiPrediction.location_id) \
             .order_by(AqiPrediction.created_at.desc()).limit(min(limit, 200)).all()
    return [{"id": p.id, "location": n, "predicted_aqi": p.predicted_aqi, "current_aqi": p.current_aqi, "category": p.category,
             "model": p.model_name, "created_at": p.created_at.isoformat(sep=" ")} for p, n in rows]
