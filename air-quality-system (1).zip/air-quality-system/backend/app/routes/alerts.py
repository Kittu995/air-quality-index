from typing import Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.db import get_db
from app.models.tables import Location, PollutionAlert, MitigationRecommendation
from app.services.ml_service import CATEGORIES

router = APIRouter(prefix="/api")


@router.get("/alerts")
def alerts(location: Optional[str] = None, limit: int = 100, db: Session = Depends(get_db)):
    q = db.query(PollutionAlert, Location.name).join(Location, Location.id == PollutionAlert.location_id)
    if location:
        q = q.filter(Location.name == location)
    rows = q.order_by(PollutionAlert.aqi.desc(), PollutionAlert.record_time.desc()).limit(min(limit, 500)).all()
    return {"delivery": "Alerts are shown in this app only. No SMS, email or push service is configured.",
            "guidance": [{"category": c[0], "advice": c[4], "color": c[2], "max_aqi": c[1]} for c in CATEGORIES],
            "alerts": [{"id": a.id, "location": n, "aqi": a.aqi, "category": a.category, "message": a.message,
                        "timestamp": a.record_time.isoformat(sep=" "), "simulated": bool(a.is_simulated)} for a, n in rows]}


@router.get("/recommendations")
def recommendations(location: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(MitigationRecommendation, Location.name).join(Location, Location.id == MitigationRecommendation.location_id)
    if location:
        q = q.filter(Location.name == location)
    order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    rows = sorted(q.all(), key=lambda r: order.get(r[0].priority, 9))
    return [{"location": n, "issue": r.issue, "action": r.action, "priority": r.priority, "expected_benefit": r.expected_benefit, "origin": r.origin} for r, n in rows]
