from fastapi import HTTPException
from sqlalchemy.orm import Session
from app.models.tables import Location, AirQualityRecord as AQ, WeatherRecord as W

POLL = ["pm25", "pm10", "co", "no2", "so2", "o3"]


def get_location(db: Session, name):
    q = db.query(Location)
    loc = q.filter_by(name=name).first() if name else q.order_by(Location.id).first()
    if not loc:
        raise HTTPException(404, "No location found. Load data first: python -m app.database.seed")
    return loc


def latest(db, loc_id):
    return db.query(AQ).filter_by(location_id=loc_id).order_by(AQ.recorded_at.desc()).first()


def last_n(db, loc_id, n):
    return list(reversed(db.query(AQ).filter_by(location_id=loc_id).order_by(AQ.recorded_at.desc()).limit(n).all()))
