"""Rule-based suggestions. They are AI/rule-generated, NOT verified interventions."""
from app.services.ml_service import compute_aqi

ORIGIN = "AI-generated suggestion (not a verified intervention)"
BENEFIT_NOTE = "Estimated direction of benefit only; measure before/after to verify."


def build(row):
    """row: dict with pm25, pm10, co, no2, so2, o3, traffic_density. Returns list of recommendation dicts."""
    aqi, dom, subs = compute_aqi(row)
    if aqi is None:
        return []
    pr = "Critical" if aqi > 300 else "High" if aqi > 200 else "Medium" if aqi > 100 else "Low"
    out = []

    def add(issue, action, benefit):
        out.append({"issue": issue, "action": action, "priority": pr, "expected_benefit": f"{benefit} {BENEFIT_NOTE}", "origin": ORIGIN})

    pm25, pm10 = row.get("pm25") or 0, row.get("pm10") or 0
    if subs.get("pm25", 0) > 100:
        add("High PM2.5", "Reduce dust-generating activities; inspect nearby construction sites; apply dust suppression (water sprinkling, covers).", "Lower fine-particle peaks near the source.")
    if subs.get("pm10", 0) > 100 and pm25 and pm10 / pm25 > 1.9:
        add("Coarse dust (PM10 high relative to PM2.5)", "Schedule road cleaning, enforce construction dust-control rules, add green barriers where space allows.", "Lower road and construction dust.")
    if (row.get("traffic_density") or 0) >= 70 and (subs.get("no2", 0) > 50 or subs.get("co", 0) > 50):
        add("Traffic-related pollution (NO2/CO with heavy traffic)", "Encourage public transport, apply traffic management at peak hours, identify high-emission corridors for review.", "Reduced vehicle NO2/CO exposure on busy corridors.")
    if subs.get("so2", 0) > 60:
        add("Possible industrial emissions (SO2)", "Request emission monitoring and inspection of control systems; flag for regulatory attention.", "Confirms or rules out an industrial source.")
    if not out:
        add("No dominant pollution issue" if aqi <= 100 else "Elevated AQI without a single clear driver",
            "Continue routine monitoring." if aqi <= 100 else "Increase monitoring frequency and review local sources.", "Maintains awareness.")
    return out
