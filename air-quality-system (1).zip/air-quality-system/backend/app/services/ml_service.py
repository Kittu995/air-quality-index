import os, sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "ml")))
from aqi_cpcb import compute_aqi, category, CATEGORIES  # noqa: E402,F401
import predict as ml_predict  # noqa: E402
