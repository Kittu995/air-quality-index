from typing import Optional
from pydantic import BaseModel, Field


class PredictIn(BaseModel):
    location: Optional[str] = None
    pm25: float = Field(ge=0, le=1000)
    pm10: float = Field(ge=0, le=1500)
    co: float = Field(ge=0, le=100, description="mg/m3")
    no2: float = Field(ge=0, le=1000)
    so2: float = Field(ge=0, le=3000)
    o3: float = Field(ge=0, le=1000)
    temperature: float = Field(ge=-20, le=60)
    humidity: float = Field(ge=0, le=100)
    wind_speed: float = Field(ge=0, le=100, description="km/h")
    traffic_density: float = Field(ge=0, le=100, description="0-100 index")
