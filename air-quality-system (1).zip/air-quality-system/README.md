# Air Quality Prediction and Urban Pollution Mitigation System

React + FastAPI + MySQL + scikit-learn/XGBoost/SHAP. AQI follows the Indian CPCB method.
**Data honesty:** the included dataset is *simulated* (`is_simulated=1`) and every page labels it as sample data.
Replace it with real data (see "Using real data") before presenting results as real.

## Folder structure
```
frontend/   React (Vite) UI: pages, charts, services
backend/    FastAPI app (routes, services, models, schemas, database/seed)
ml/         dataset/, train_model.py, predict.py, evaluation.py, aqi_cpcb.py, model/ (outputs)
database/   schema.sql (MySQL)
reports/    (PDFs are generated on demand by the API)
```

## 1. Install (Python 3.10+, Node 18+, MySQL 8)
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
cd frontend && npm install && cd ..
```

## 2. Configure
```bash
cp .env.example .env        # edit DATABASE_URL with your MySQL password
```
MySQL: `mysql -u root -p < database/schema.sql` (optional: the seed script also creates the tables).
No MySQL yet? set `DATABASE_URL=sqlite:///./airquality.db` for a quick demo.

## 3. Train the model (from `ml/`)
```bash
cd ml
python generate_sample_dataset.py      # only if you have no real CSV
python train_model.py                  # trains RF + XGBoost, saves model/aqi_model.joblib, metrics.json, plots
cd ..
```
Time-based split (last 20% of dates is the test set), target = next-day AQI. Metrics: MAE, MSE, RMSE, R2, plus
category accuracy/precision/recall/F1. The lowest-RMSE model is saved. SHAP importance goes to `ml/model/`.

## 4. Load the database and run (from `backend/`)
```bash
cd backend
python -m app.database.seed            # loads ml/dataset/air_quality.csv, builds alerts + recommendations
uvicorn app.main:app --reload          # API on http://localhost:8000  (docs at /docs)
```
Frontend, in a second terminal: `cd frontend && npm run dev` → http://localhost:5173

## API
| Method | Path | Purpose |
|---|---|---|
| GET | /api/health | status |
| GET | /api/locations | monitoring locations |
| GET | /api/dashboard?location= | latest AQI, pollutants, weather, 30-record trend, last 7 |
| GET | /api/air-quality | filtered records: location,start,end,pollutant,min_value,sort_by,order,limit,offset |
| GET | /api/air-quality/csv | same filters, CSV download |
| GET | /api/analytics | location,start,end,granularity=daily/weekly/monthly/yearly |
| POST | /api/predict | 10 numeric inputs (validated) → predicted AQI, SHAP explanation, suggestions |
| GET | /api/predictions | stored predictions |
| GET | /api/hotspots | latest AQI per location with coordinates; hotspot if AQI ≥ HOTSPOT_AQI |
| GET | /api/alerts | alerts + health guidance (in-app only) |
| GET | /api/recommendations | mitigation suggestions (AI/rule-generated, not verified) |
| GET | /api/reports?type=aqi/hotspot/monthly | report data; `/api/reports/pdf` downloads PDF |

## Using real data
Create `ml/dataset/air_quality.csv` with columns:
`station,datetime,lat,lon,pm25,pm10,co,no2,so2,o3,temperature,humidity,wind_speed,traffic_density,aqi,source,is_simulated`
(CPCB/OpenAQ pollutants, Open-Meteo weather, real station coordinates; set `is_simulated=0`). `aqi` may be empty; it is then computed
by CPCB. Re-run `train_model.py` and the seed script. Live OpenAQ/Open-Meteo ingestion is not included yet.

## Deployment (outline)
Build frontend (`npm run build`) and serve `frontend/dist` with Nginx; run `uvicorn app.main:app --host 0.0.0.0` behind it (or gunicorn);
set `CORS_ORIGINS` to your site, keep `.env` out of git, use a managed MySQL.

## Not included
User login (the `users` table exists), live API ingestion, external alert delivery (SMS/email).
