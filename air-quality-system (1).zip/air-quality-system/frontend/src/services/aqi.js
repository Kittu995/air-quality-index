// Indian CPCB National AQI: sub-index per pollutant by linear interpolation
// across breakpoints; overall AQI = the maximum sub-index.
// Units: PM2.5, PM10, NO2, SO2, O3 in µg/m³; CO in mg/m³.
const INDEX_BANDS = [[0, 50], [51, 100], [101, 200], [201, 300], [301, 400], [401, 500]];

// Concentration ranges for the six bands (Good ... Severe).
const BREAKPOINTS = {
  pm25: [[0, 30], [31, 60], [61, 90], [91, 120], [121, 250], [251, 380]],
  pm10: [[0, 50], [51, 100], [101, 250], [251, 350], [351, 430], [431, 600]],
  no2:  [[0, 40], [41, 80], [81, 180], [181, 280], [281, 400], [401, 600]],
  o3:   [[0, 50], [51, 100], [101, 168], [169, 208], [209, 748], [749, 1000]],
  co:   [[0, 1.0], [1.1, 2.0], [2.1, 10], [10.1, 17], [17.1, 34], [34.1, 50]],
  so2:  [[0, 40], [41, 80], [81, 380], [381, 800], [801, 1600], [1601, 2000]],
};

export const CATEGORIES = [
  { name: "Good", max: 50, color: "#1f9d55", risk: "Minimal", advice: "Air quality is satisfactory. No precautions needed." },
  { name: "Satisfactory", max: 100, color: "#9bc53d", risk: "Low", advice: "Unusually sensitive people may notice minor breathing discomfort." },
  { name: "Moderate", max: 200, color: "#f2b035", risk: "Moderate", advice: "People with lung or heart disease, children and older adults should limit prolonged exertion." },
  { name: "Poor", max: 300, color: "#ee7d2f", risk: "High", advice: "Reduce prolonged outdoor exposure. Sensitive groups should stay indoors." },
  { name: "Very Poor", max: 400, color: "#d0342c", risk: "Very high", advice: "Avoid unnecessary outdoor activity. Use a well-fitted mask outdoors." },
  { name: "Severe", max: 500, color: "#7b2d8e", risk: "Severe", advice: "Urgent: stay indoors, keep windows closed and follow local authority advice." },
];

export function categoryFor(aqi) {
  return CATEGORIES.find((c) => aqi <= c.max) || CATEGORIES[CATEGORIES.length - 1];
}

function subIndex(key, value) {
  const bps = BREAKPOINTS[key];
  if (value == null || Number.isNaN(value) || !bps) return null;
  let i = bps.findIndex(([, hi]) => value <= hi);
  if (i === -1) i = bps.length - 1;
  const [cLo, cHi] = bps[i];
  const [iLo, iHi] = INDEX_BANDS[i];
  const v = Math.min(Math.max(value, cLo), cHi);
  return Math.round(((iHi - iLo) / (cHi - cLo)) * (v - cLo) + iLo);
}

/** CPCB requires PM2.5 or PM10 plus at least 3 pollutants in total. */
export function computeAqi(p) {
  const subs = {};
  Object.keys(BREAKPOINTS).forEach((k) => {
    const s = subIndex(k, p[k]);
    if (s != null) subs[k] = s;
  });
  const keys = Object.keys(subs);
  if (keys.length < 3 || (subs.pm25 == null && subs.pm10 == null)) return null;
  const dominant = keys.reduce((a, b) => (subs[a] >= subs[b] ? a : b));
  const aqi = subs[dominant];
  return { aqi, dominant, subIndices: subs, ...categoryFor(aqi) };
}

export const POLLUTANTS = [
  { key: "pm25", label: "PM2.5", unit: "µg/m³" },
  { key: "pm10", label: "PM10", unit: "µg/m³" },
  { key: "co", label: "CO", unit: "mg/m³" },
  { key: "no2", label: "NO₂", unit: "µg/m³" },
  { key: "so2", label: "SO₂", unit: "µg/m³" },
  { key: "o3", label: "O₃", unit: "µg/m³" },
];
