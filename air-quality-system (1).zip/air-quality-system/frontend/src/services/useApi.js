import { useCallback, useEffect, useState } from "react";
import { api } from "./api.js";

export function useApi(path) {
  const [state, set] = useState({ data: null, error: null, loading: true });
  const load = useCallback(() => {
    set({ data: null, error: null, loading: true });
    api(path).then((data) => set({ data, error: null, loading: false })).catch((e) => set({ data: null, error: e.message, loading: false }));
  }, [path]);
  useEffect(load, [load]);
  return { ...state, reload: load };
}
