import { getSample } from "../assets/sampleData.js";

const BASE = import.meta.env.VITE_API_URL || "";

async function getJson(path, ms = 6000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(`${BASE}${path}`, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`Server responded ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

/** Real backend first; clearly labelled sample data if the backend is not running. */
export async function fetchDashboard(location) {
  try {
    const data = await getJson(`/api/dashboard?location=${encodeURIComponent(location)}`);
    return { ...data, simulated: false };
  } catch (err) {
    return { ...getSample(location), fallbackReason: err.message };
  }
}

export const apiUrl = (path) => `${BASE}${path}`;

/** JSON request with readable errors (FastAPI 422 details are flattened). */
export async function api(path, opts = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, opts);
  } catch {
    throw new Error("Cannot reach the backend. Start it with: uvicorn app.main:app --reload (in /backend).");
  }
  if (!res.ok) {
    let d;
    try { d = (await res.json()).detail; } catch { /* ignore */ }
    const msg = typeof d === "string" ? d : Array.isArray(d) ? d.map((x) => `${x.loc.slice(-1)}: ${x.msg}`).join("; ") : `Server responded ${res.status}`;
    throw new Error(msg);
  }
  return res.json();
}

export const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== "" && v != null)).toString();
