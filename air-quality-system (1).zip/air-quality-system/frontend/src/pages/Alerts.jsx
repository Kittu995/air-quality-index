import { useOutletContext } from "react-router-dom";
import { useApi } from "../services/useApi.js";
import { Loading, ErrorBox, Empty } from "../components/StateViews.jsx";
import { categoryFor } from "../services/aqi.js";

export default function Alerts() {
  const { location } = useOutletContext();
  const { data, error, loading, reload } = useApi(`/api/alerts?location=${encodeURIComponent(location)}`);
  if (loading) return <Loading />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  return (
    <section>
      <h2 className="page-title">Pollution Alerts</h2>
      <div className="banner" role="note">{data.delivery}</div>
      <div className="card"><h3>Alerts for {location}</h3>
        {!data.alerts.length ? <Empty title="No alerts" hint="No readings above AQI 100 in the stored period." /> :
          <ul className="alerts">{data.alerts.map((a) => (
            <li key={a.id} style={{ borderLeftColor: categoryFor(a.aqi).color }}>
              <strong>{a.category} · AQI {a.aqi}</strong><span>{a.message}</span>
              <small>{a.timestamp}{a.simulated ? " · simulated sample data" : ""}</small>
            </li>))}</ul>}
      </div>
      <div className="card"><h3>Health precautions by category</h3>
        <ul className="plain">{data.guidance.map((g) => <li key={g.category}><b style={{ color: g.color }}>{g.category}</b> (up to {g.max_aqi}): {g.advice}</li>)}</ul>
      </div>
    </section>
  );
}
