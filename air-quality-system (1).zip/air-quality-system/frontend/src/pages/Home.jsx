import { Link } from "react-router-dom";
import { CATEGORIES } from "../services/aqi.js";

const STEPS = [
  ["Collect", "Air quality, weather and traffic data are loaded from datasets, OpenAQ, Open-Meteo and sensors."],
  ["Clean", "Missing values and duplicates are handled before modelling."],
  ["Predict", "Random Forest and XGBoost models estimate the next AQI."],
  ["Explain", "SHAP shows which factors pushed the prediction up or down."],
  ["Act", "Hotspots and mitigation actions are suggested for city authorities."],
];
const FEATURES = [
  ["AQI monitoring", "CPCB-based AQI with pollutant and weather readings.", "/dashboard"],
  ["AQI prediction", "Enter conditions and get a model-based forecast.", "/predict"],
  ["Hotspot map", "See which locations need attention first.", "/map"],
  ["Mitigation advice", "Actions matched to the cause of pollution.", "/mitigation"],
];

export default function Home() {
  return (
    <div className="home">
      <section className="hero">
        <h2>Know the air before you breathe it.</h2>
        <p>
          An AI-powered system that monitors air pollution, predicts the Air Quality Index,
          finds pollution hotspots and suggests how cities can reduce them.
        </p>
        <Link className="btn big" to="/dashboard">Explore Dashboard</Link>
        <div className="scale hero-scale" aria-label="Indian CPCB AQI categories">
          {CATEGORIES.map((c) => (
            <div key={c.name} style={{ background: c.color }}>
              <b>{c.name}</b><span>{c.max === 500 ? "401–500" : `≤ ${c.max}`}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <h3>Why air pollution matters</h3>
        <p>
          Fine particles (PM2.5) and gases such as NO₂ and SO₂ enter the lungs and bloodstream.
          Traffic, industry, construction dust and burning are the main urban sources. Knowing where and
          when pollution peaks lets people protect themselves and lets authorities act on the source.
        </p>
      </section>

      <section>
        <h3>Objectives</h3>
        <ul className="plain">
          <li>Monitor current air quality using the CPCB AQI method.</li>
          <li>Predict future AQI with machine learning, without fabricated results.</li>
          <li>Identify pollution hotspots on an interactive map.</li>
          <li>Recommend mitigation actions, marked as AI suggestions.</li>
        </ul>
      </section>

      <section>
        <h3>How it works</h3>
        <ol className="steps">
          {STEPS.map(([t, d]) => <li key={t}><strong>{t}</strong><span>{d}</span></li>)}
        </ol>
      </section>

      <section>
        <h3>Main features</h3>
        <div className="grid feats">
          {FEATURES.map(([t, d, to]) => (
            <Link key={t} to={to} className="card feat"><strong>{t}</strong><span>{d}</span></Link>
          ))}
        </div>
      </section>

      <section className="card">
        <h3>What you can do</h3>
        <p>
          Check AQI before outdoor exercise, prefer public transport on poor-air days, keep windows closed
          during severe episodes, and report dust or burning to your local pollution control board.
        </p>
      </section>

      <footer className="footer">
        Air Quality Prediction and Urban Pollution Mitigation System · Final-year B.Tech CSE (AI &amp; ML) project
      </footer>
    </div>
  );
}
