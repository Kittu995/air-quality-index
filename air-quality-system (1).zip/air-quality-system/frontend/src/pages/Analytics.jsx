import { useState } from "react";
import { useOutletContext } from "react-router-dom";
import { Line, Bar, Scatter } from "react-chartjs-2";
import { useApi } from "../services/useApi.js";
import { qs } from "../services/api.js";
import { Loading, ErrorBox, Empty } from "../components/StateViews.jsx";
import "../charts/charts.jsx";

const base = { responsive: true, maintainAspectRatio: false };
const scat = (title, x) => ({ ...base, plugins: { legend: { display: false } }, scales: { x: { title: { display: true, text: x } }, y: { title: { display: true, text: "AQI" } } } });

export default function Analytics() {
  const { location, locations } = useOutletContext();
  const [f, setF] = useState({ loc: "", start: "", end: "", granularity: "daily" });
  const chosen = f.loc === "all" ? "" : f.loc || location;
  const { data, error, loading, reload } = useApi(`/api/analytics?${qs({ location: chosen, start: f.start, end: f.end, granularity: f.granularity })}`);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <section>
      <h2 className="page-title">Air Quality Analytics</h2>
      <div className="card row filters">
        <label>Location<select value={f.loc || location} onChange={set("loc")}><option value="all">All locations</option>{locations.map((l) => <option key={l}>{l}</option>)}</select></label>
        <label>From<input type="date" value={f.start} onChange={set("start")} /></label>
        <label>To<input type="date" value={f.end} onChange={set("end")} /></label>
        <label>Trend<select value={f.granularity} onChange={set("granularity")}>{["daily", "weekly", "monthly", "yearly"].map((g) => <option key={g}>{g}</option>)}</select></label>
      </div>
      {loading && <Loading />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data?.empty && <Empty title="No data for these filters" hint="Widen the date range or choose another location." />}
      {data && !data.empty && (() => {
        const lab = data.series.map((s) => s.label), P = data.pollutants;
        return (
          <div className="grid charts">
            <div className="card"><h3>AQI trend ({data.granularity})</h3><div className="chart"><Line options={base} data={{ labels: lab, datasets: [{ label: "AQI", data: data.series.map((s) => s.aqi), borderColor: "#1d6fa5", pointRadius: 0, tension: 0.3 }] }} /></div></div>
            <div className="card"><h3>PM2.5 and PM10 trends</h3><div className="chart"><Line options={base} data={{ labels: lab, datasets: [
              { label: "PM2.5", data: data.series.map((s) => s.pm25), borderColor: "#13a87b", pointRadius: 0 }, { label: "PM10", data: data.series.map((s) => s.pm10), borderColor: "#0b2545", pointRadius: 0 }] }} /></div></div>
            <div className="card"><h3>Mean pollutant levels</h3><div className="chart"><Bar options={{ ...base, plugins: { legend: { display: false } } }} data={{ labels: ["PM2.5", "PM10", "CO", "NO₂", "SO₂", "O₃"], datasets: [{ data: [P.pm25, P.pm10, P.co, P.no2, P.so2, P.o3], backgroundColor: "#1d6fa5", borderRadius: 4 }] }} /></div><p className="muted">CO is in mg/m³; others in µg/m³.</p></div>
            <div className="card"><h3>Location-wise mean AQI</h3><div className="chart"><Bar options={{ ...base, indexAxis: "y", plugins: { legend: { display: false } } }} data={{ labels: data.locations.map((l) => l.location), datasets: [{ data: data.locations.map((l) => l.aqi), backgroundColor: "#13a87b", borderRadius: 4 }] }} /></div></div>
            {[["temperature", "Temperature (°C)"], ["humidity", "Humidity (%)"], ["wind_speed", "Wind speed (km/h)"]].map(([k, t]) => (
              <div className="card" key={k}><h3>{t.split(" (")[0]} vs AQI</h3>
                {data.scatter[k].length ? <div className="chart"><Scatter options={scat(t, t)} data={{ datasets: [{ data: data.scatter[k], backgroundColor: "rgba(29,111,165,.45)", pointRadius: 2.5 }] }} /></div> : <Empty title="No weather data" hint="No matching weather records." />}</div>))}
          </div>);
      })()}
    </section>
  );
}
