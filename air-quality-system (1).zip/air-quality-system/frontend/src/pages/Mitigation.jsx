import { useState } from "react";
import { useOutletContext } from "react-router-dom";
import { useApi } from "../services/useApi.js";
import { Loading, ErrorBox, Empty } from "../components/StateViews.jsx";

export default function Mitigation() {
  const { location } = useOutletContext();
  const [all, setAll] = useState(false);
  const { data, error, loading, reload } = useApi(`/api/recommendations${all ? "" : `?location=${encodeURIComponent(location)}`}`);
  return (
    <section>
      <h2 className="page-title">Mitigation Recommendations</h2>
      <div className="banner" role="note">These are AI/rule-generated suggestions from current readings. They are not verified interventions; confirm with field inspection before acting.</div>
      <label className="check"><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} /> Show all locations</label>
      {loading && <Loading />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data && !data.length && <Empty title="No recommendations" hint="Seed the database to generate them." />}
      <div className="grid charts">{data?.map((r, i) => (
        <div className="card rec" key={i}>
          <span className={`chip prio-${r.priority}`}>{r.priority} priority</span>
          <h3>{r.issue}</h3>
          <p className="muted">Location: {r.location}</p>
          <p><b>Suggested action:</b> {r.action}</p>
          <p><b>Expected benefit:</b> {r.expected_benefit}</p>
          <small className="muted">{r.origin}</small>
        </div>))}
      </div>
    </section>
  );
}
