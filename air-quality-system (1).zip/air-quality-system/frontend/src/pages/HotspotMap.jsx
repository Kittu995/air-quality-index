import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useApi } from "../services/useApi.js";
import { Loading, ErrorBox, Empty } from "../components/StateViews.jsx";
import { CATEGORIES } from "../services/aqi.js";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export default function HotspotMap() {
  const { data, error, loading, reload } = useApi("/api/hotspots");
  const [filter, setFilter] = useState("All");
  const el = useRef(null), map = useRef(null), layer = useRef(null);

  useEffect(() => {
    if (!data?.locations?.length || map.current) return;
    map.current = L.map(el.current).setView([data.locations[0].latitude, data.locations[0].longitude], 11);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "&copy; OpenStreetMap contributors", maxZoom: 18 }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => { map.current?.remove(); map.current = null; };
  }, [data]);

  useEffect(() => {
    if (!layer.current || !data) return;
    layer.current.clearLayers();
    const shown = data.locations.filter((l) => filter === "All" || l.category === filter);
    shown.forEach((l) => {
      if (l.is_hotspot) L.circle([l.latitude, l.longitude], { radius: 1500, color: l.color, weight: 2, dashArray: "4", fillOpacity: 0.08 }).addTo(layer.current);
      L.circleMarker([l.latitude, l.longitude], { radius: 11, color: "#fff", weight: 2, fillColor: l.color, fillOpacity: 0.95 })
        .bindPopup(`<b>${esc(l.location)}</b>${l.is_hotspot ? " (hotspot)" : ""}<br>AQI: <b>${esc(l.aqi)}</b> (${esc(l.category)})<br>PM2.5: ${esc(l.pm25)} µg/m³<br>PM10: ${esc(l.pm10)} µg/m³<br>Recorded: ${esc(l.recorded_at)}<br><small>${esc(l.source)}${l.simulated ? " · simulated position and data" : ""}</small>`)
        .addTo(layer.current);
    });
    if (shown.length) map.current.fitBounds(shown.map((l) => [l.latitude, l.longitude]), { padding: [40, 40], maxZoom: 13 });
  }, [data, filter]);

  if (loading) return <Loading />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data.locations.length) return <Empty title="No monitoring locations" hint="Load data with python -m app.database.seed." />;
  const hot = data.locations.filter((l) => l.is_hotspot);
  return (
    <section>
      <h2 className="page-title">Pollution Hotspot Map</h2>
      {data.locations.some((l) => l.simulated) && <div className="banner">Sample data: station positions and readings are simulated for demonstration.</div>}
      <div className="row filters">
        <label>Show category
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option>All</option>{CATEGORIES.map((c) => <option key={c.name}>{c.name}</option>)}
          </select>
        </label>
        <span className="muted">Hotspot = AQI ≥ {data.threshold}. Dashed rings mark hotspots. {hot.length} found.</span>
      </div>
      <div ref={el} className="map" />
      <div className="legend">{CATEGORIES.map((c) => <span key={c.name}><i style={{ background: c.color }} />{c.name}</span>)}</div>
    </section>
  );
}
