import { useState } from "react";
import { useOutletContext } from "react-router-dom";
import { api, apiUrl, qs } from "../services/api.js";
import { ErrorBox } from "../components/StateViews.jsx";

const TYPES = [["aqi", "AQI report"], ["hotspot", "Pollution hotspot report"], ["monthly", "Monthly pollution report"]];
export default function Reports() {
  const { location } = useOutletContext();
  const [type, setType] = useState("aqi");
  const [rep, setRep] = useState(null);
  const [err, setErr] = useState(null);
  const q = qs({ type, location: type === "hotspot" ? "" : location });
  const preview = async () => { setErr(null); try { setRep(await api(`/api/reports?${q}`)); } catch (e) { setErr(e.message); } };
  return (
    <section>
      <h2 className="page-title">Reports</h2>
      <div className="card row filters">
        <label>Report<select value={type} onChange={(e) => { setType(e.target.value); setRep(null); }}>{TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>
        <span className="muted">Location: {type === "hotspot" ? "all" : location}</span>
        <button className="btn ghost" onClick={preview}>Preview</button>
        <a className="btn" href={apiUrl(`/api/reports/pdf?${q}`)}>Download PDF</a>
        <a className="btn" href={apiUrl(`/api/air-quality/csv?${qs({ location: type === "hotspot" ? "" : location })}`)}>Download CSV</a>
      </div>
      {err && <ErrorBox message={err} />}
      {rep && (
        <div className="card scroll">
          <h3>{rep.title}</h3>
          <p className="muted">{rep.location} · generated {rep.generated}{rep.simulated ? " · contains simulated sample data" : ""}</p>
          <ul className="plain">{rep.summary.map(([a, b]) => <li key={a}>{a}: <b>{b}</b></li>)}</ul>
          <table><tbody>{rep.table.map((r, i) => <tr key={i}>{r.map((c, j) => i ? <td key={j}>{c}</td> : <th key={j}>{c}</th>)}</tr>)}</tbody></table>
          {rep.recs.map((m, i) => <p key={i}><b>[{m.priority}] {m.issue}:</b> {m.action}</p>)}
        </div>)}
    </section>
  );
}
