import { useState } from "react";
import { useOutletContext } from "react-router-dom";
import { Line } from "react-chartjs-2";
import { useApi } from "../services/useApi.js";
import { apiUrl, qs } from "../services/api.js";
import { Loading, ErrorBox, Empty } from "../components/StateViews.jsx";
import "../charts/charts.jsx";

const PAGE = 25;
export default function History() {
  const { location, locations } = useOutletContext();
  const [f, setF] = useState({ loc: "", start: "", end: "", pollutant: "", min_value: "", sort_by: "recorded_at", order: "desc" });
  const [page, setPage] = useState(0);
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setPage(0); };
  const filt = { location: f.loc === "all" ? "" : f.loc || location, start: f.start, end: f.end, pollutant: f.pollutant, min_value: f.pollutant ? f.min_value : "", sort_by: f.sort_by, order: f.order };
  const { data, error, loading, reload } = useApi(`/api/air-quality?${qs({ ...filt, limit: PAGE, offset: page * PAGE })}`);

  return (
    <section>
      <h2 className="page-title">Historical Data</h2>
      <div className="card row filters">
        <label>Location<select value={f.loc || location} onChange={set("loc")}><option value="all">All locations</option>{locations.map((l) => <option key={l}>{l}</option>)}</select></label>
        <label>From<input type="date" value={f.start} onChange={set("start")} /></label>
        <label>To<input type="date" value={f.end} onChange={set("end")} /></label>
        <label>Pollutant<select value={f.pollutant} onChange={set("pollutant")}><option value="">Any</option>{["pm25", "pm10", "co", "no2", "so2", "o3"].map((p) => <option key={p}>{p}</option>)}</select></label>
        <label>At least<input type="number" value={f.min_value} disabled={!f.pollutant} onChange={set("min_value")} /></label>
        <label>Sort by<select value={f.sort_by} onChange={set("sort_by")}>{["recorded_at", "aqi", "pm25", "pm10", "location"].map((p) => <option key={p}>{p}</option>)}</select></label>
        <label>Order<select value={f.order} onChange={set("order")}><option>desc</option><option>asc</option></select></label>
        <a className="btn" href={apiUrl(`/api/air-quality/csv?${qs(filt)}`)}>Download CSV</a>
      </div>
      {loading && <Loading />}
      {error && <ErrorBox message={error} onRetry={reload} />}
      {data && !data.rows.length && <Empty title="No records match" hint="Change or clear the filters." />}
      {data?.rows.length > 0 && (<>
        <div className="card"><h3>Trend of this page (by record time)</h3><div className="chart small">
          <Line options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }}
            data={{ labels: [...data.rows].reverse().map((r) => r.recorded_at.slice(0, 10)), datasets: [{ data: [...data.rows].reverse().map((r) => r.aqi), borderColor: "#1d6fa5", tension: 0.3 }] }} /></div></div>
        <div className="card scroll"><table>
          <thead><tr>{["Time", "Location", "AQI", "Category", "PM2.5", "PM10", "CO", "NO₂", "SO₂", "O₃", "Source"].map((h) => <th key={h}>{h}</th>)}</tr></thead>
          <tbody>{data.rows.map((r, i) => <tr key={i}><td>{r.recorded_at.slice(0, 16)}</td><td>{r.location}</td><td>{r.aqi}</td><td>{r.category}</td><td>{r.pm25}</td><td>{r.pm10}</td><td>{r.co}</td><td>{r.no2}</td><td>{r.so2}</td><td>{r.o3}</td><td>{r.source}{r.simulated ? " (simulated)" : ""}</td></tr>)}</tbody>
        </table></div>
        <div className="row"><button className="btn ghost" disabled={!page} onClick={() => setPage(page - 1)}>Previous</button>
          <span className="muted">Page {page + 1} of {Math.max(1, Math.ceil(data.total / PAGE))} · {data.total} records</span>
          <button className="btn ghost" disabled={(page + 1) * PAGE >= data.total} onClick={() => setPage(page + 1)}>Next</button></div>
      </>)}
    </section>
  );
}
