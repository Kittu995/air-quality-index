import { useCallback, useEffect, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { fetchDashboard } from "../services/api.js";
import { computeAqi, CATEGORIES, POLLUTANTS } from "../services/aqi.js";
import { Loading, ErrorBox, Empty } from "../components/StateViews.jsx";
import { AqiTrend, PmCompare, Distribution, Weekly } from "../charts/charts.jsx";

export default function Dashboard() {
  const { location } = useOutletContext();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setData(null); setError(null);
    try { setData(await fetchDashboard(location)); }
    catch (e) { setError(e.message); }
  }, [location]);

  useEffect(() => { load(); }, [load]);

  if (error) return <ErrorBox message={error} onRetry={load} />;
  if (!data) return <Loading />;
  const result = data.current ? computeAqi(data.current) : null;
  if (!result) return <Empty title="No observations for this location" hint="CPCB needs PM2.5 or PM10 plus at least three pollutants." />;

  const w = data.weather || {};
  return (
    <section>
      <h2 className="page-title">Dashboard</h2>
      {data.simulated && (
        <div className="banner" role="note">
          <strong>Sample data.</strong> These values are simulated for demonstration, not live measurements.
          {data.fallbackReason && <> Backend not reachable ({data.fallbackReason}).</>}
        </div>
      )}

      <div className="grid hero-grid">
        <div className="card aqi-card" style={{ "--c": result.color }}>
          <div className="aqi-num">{result.aqi}</div>
          <div>
            <div className="aqi-cat">{result.name}</div>
            <div className="muted">Pollution risk: {result.risk}</div>
            <p>{result.advice}</p>
            <div className="meta">
              {data.location} · Updated {new Date(data.updatedAt).toLocaleString()} · Source: {data.source}
            </div>
          </div>
        </div>
        <div className="card">
          <h3>Weather</h3>
          <dl className="weather">
            <div><dt>Temperature</dt><dd>{w.temperature} °C</dd></div>
            <div><dt>Humidity</dt><dd>{w.humidity} %</dd></div>
            <div><dt>Wind speed</dt><dd>{w.windSpeed} km/h</dd></div>
            <div><dt>Condition</dt><dd>{w.condition}</dd></div>
          </dl>
        </div>
      </div>

      <div className="grid tiles">
        {POLLUTANTS.map((p) => (
          <div className="card tile" key={p.key}>
            <span className="muted">{p.label}</span>
            <strong>{data.current[p.key]}</strong>
            <span className="muted">{p.unit}</span>
            {result.dominant === p.key && <span className="chip">Dominant</span>}
          </div>
        ))}
      </div>

      <div className="card">
        <h3>Pollution status (CPCB)</h3>
        <div className="scale" role="list">
          {CATEGORIES.map((c) => (
            <div key={c.name} role="listitem" className={c.name === result.name ? "on" : ""} style={{ background: c.color }}>
              {c.name}
            </div>
          ))}
        </div>
      </div>

      <div className="grid charts">
        <div className="card"><h3>AQI trend</h3><div className="chart"><AqiTrend trend={data.trend} /></div></div>
        <div className="card"><h3>PM2.5 and PM10</h3><div className="chart"><PmCompare trend={data.trend} /></div></div>
        <div className="card"><h3>Pollutant share (sub-index)</h3><div className="chart"><Distribution subIndices={result.subIndices} /></div></div>
        <div className="card"><h3>Weekly air quality</h3><div className="chart"><Weekly weekly={data.weekly} /></div></div>
      </div>
    </section>
  );
}
