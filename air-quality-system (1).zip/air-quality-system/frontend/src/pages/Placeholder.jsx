import { Link } from "react-router-dom";
import { Empty } from "../components/StateViews.jsx";

export default function Placeholder({ title, step }) {
  return (
    <section>
      <h2 className="page-title">{title}</h2>
      <div className="card">
        <Empty title="This module is not built yet" hint={`Planned: ${step}.`} />
        <Link className="btn" to="/dashboard">Back to dashboard</Link>
      </div>
    </section>
  );
}
