import { useState } from "react";
import { useOutletContext } from "react-router-dom";
import { Bar } from "react-chartjs-2";
import { api } from "../services/api.js";
import { ErrorBox } from "../components/StateViews.jsx";
import "../charts/charts.jsx";

const FIELDS = [
  ["pm25", "PM2.5 (µg/m³)", 0, 1000, 60], ["pm10", "PM10 (µg/m³)", 0, 1500, 110], ["co", "CO (mg/m³)", 0, 100, 1],
  ["no2", "NO₂ (µg/m³)", 0, 1000, 40], ["so2", "SO₂ (µg/m³)", 0, 3000, 12], ["o3", "O₃ (µg/m³)", 0, 1000, 40],
  ["temperature", "Temperature (°C)", -20, 60, 27], ["humidity", "Humidity (%)", 0, 100, 60],
  ["wind_speed", "Wind speed (km/h)", 0, 100, 8], ["traffic_density", "Traffic density (0–100)", 0, 100, 50],
];

export default function Predict() {
  const { location } = useOutletContext();
  const [v, setV] = useState(Object.fromEntries(FIELDS.map(([k, , , , d]) => [k, String(d)])));
  const [res, setRes] = useState(null);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  const prefill = async () => {
    setErr(null);
    try {
      const d = await api(`/api/dashboard?location=${encodeURIComponent(location)}`);
      setV((o) => ({ ...o, ...Object.fromEntries(Object.entries(d.current).map(([k, x]) => [k, String(x)])),
        ...(d.weather ? { temperature: String(d.weather.temperature), humidity: String(d.weather.humidity), wind_speed: String(d.weather.windSpeed) } : {}) }));
      setNote(`Filled from the latest stored record for ${d.location}${d.simulated ? " (simulated sample data)" : ""}. Traffic density is not in that record; edit it.`);
    } catch (e) { setErr(e.message); }
  };

  const submit = async (e) => {
    e.preventDefault(); setErr(null); setRes(null);
    for (const [k, label, lo, hi] of FIELDS) {
      const n = Number(v[k]);
      if (v[k] === "" || Number.isNaN(n) || n < lo || n > hi) return setErr(`${label} must be a number between ${lo} and ${hi}.`);
    }
    setBusy(true);
    try {
      const body = { location, ...Object.fromEntries(FIELDS.map(([k]) => [k, Number(v[k])])) };
      setRes(await api("/api/predict", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }));
    } catch (e2) { setErr(e2.message); } finally { setBusy(false); }
  };

  return (
    <section>
      <h2 className="page-title">AQI Prediction</h2>
      <form className="card form" onSubmit={submit}>
        <p className="muted">Location: <strong>{location}</strong>. The model forecasts the next-day AQI from these conditions.</p>
        <div className="fields">
          {FIELDS.map(([k, label, lo, hi]) => (
            <label key={k}>{label}
              <input type="number" step="any" min={lo} max={hi} value={v[k]} onChange={(e) => setV({ ...v, [k]: e.target.value })} required />
            </label>
          ))}
        </div>
        {note && <p className="muted">{note}</p>}
        <div className="row">
          <button className="btn" disabled={busy}>{busy ? "Predicting…" : "Predict AQI"}</button>
          <button type="button" className="btn ghost" onClick={prefill}>Use latest stored values</button>
        </div>
      </form>
      {err && <ErrorBox message={err} />}
      {res && <Result r={res} />}
    </section>
  );
}

function Result({ r }) {
  const c = r.category;
  return (
    <>
      {r.simulated_training_data && <div className="banner">The model was trained on a simulated sample dataset, so this forecast is a demonstration only.</div>}
      <div className="grid hero-grid">
        <div className="card aqi-card" style={{ "--c": c.color }}>
          <div className="aqi-num">{r.predicted_aqi}</div>
          <div>
            <div className="aqi-cat">{c.name}</div>
            <div className="muted">Pollution risk: {c.risk} · Model: {r.model}</div>
            <p>{c.advice}</p>
            {r.uncertainty ? <div className="meta">Likely range {r.uncertainty.low}–{r.uncertainty.high}. {r.uncertainty.note}.</div>
              : <div className="meta">No uncertainty shown: {r.model} does not provide it here.</div>}
          </div>
        </div>
        <div className="card"><h3>Current vs predicted AQI</h3>
          <div className="chart small">
            <Bar options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }}
              data={{ labels: ["Current (from inputs)", "Predicted"], datasets: [{ data: [r.current_aqi, r.predicted_aqi], backgroundColor: ["#1d6fa5", c.color], borderRadius: 6 }] }} />
          </div>
        </div>
      </div>
      <div className="grid charts">
        <div className="card"><h3>Why this forecast</h3>
          <p className="muted">Baseline average forecast {r.base_value}. Each factor moves it up or down (SHAP).</p>
          <ul className="shap">{r.explanation.slice(0, 6).map((x) => (
            <li key={x.feature} className={x.effect > 0 ? "up" : "down"}>
              <span style={{ width: `${Math.min(100, Math.abs(x.effect) * 2)}%` }} /><em>{x.text}</em>
            </li>))}</ul>
        </div>
        {r.global_importance && <div className="card"><h3>Overall feature importance</h3><div className="chart">
          <Bar options={{ indexAxis: "y", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }}
            data={{ labels: Object.keys(r.global_importance), datasets: [{ data: Object.values(r.global_importance), backgroundColor: "#13a87b", borderRadius: 4 }] }} /></div></div>}
      </div>
      <div className="card"><h3>Mitigation suggestions</h3>
        {r.recommendations.map((m, i) => <p key={i}><b>[{m.priority}] {m.issue}:</b> {m.action} <span className="chip warn">{m.origin}</span></p>)}
      </div>
    </>
  );
}
