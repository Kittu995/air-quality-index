const S = [
  ["Introduction", "Air pollution from traffic, industry, dust and burning harms health in fast-growing cities. This project monitors air quality, forecasts the Indian CPCB AQI, locates hotspots and suggests mitigation."],
  ["Problem statement", "City authorities and residents lack a single, explainable tool that links current pollution, short-term forecasts and practical actions."],
  ["Objectives", "Monitor AQI by CPCB method; predict next-day AQI with machine learning; explain predictions with SHAP; map hotspots; recommend actions; keep observations, predictions and simulated data clearly separate."],
  ["Existing system", "Existing portals mainly display current readings. Research systems use statistical models such as ARIMA and regression, classical machine learning (Random Forest, SVR, LSTM), and recent work on quantum-based methods such as QSVM and quantum-inspired optimisation."],
  ["Limitations of existing systems", "Statistical models handle non-linear atmospheric data poorly; many predictors are black boxes; few connect forecasts to mitigation advice; quantum approaches need specialised hardware or simulation and are hard to deploy."],
  ["Proposed system", "A web platform with a React frontend, FastAPI backend, MySQL database and a Random Forest / XGBoost forecaster, with SHAP explanations, a Leaflet hotspot map, alerts and PDF/CSV reports."],
  ["Proposed methodology", "Load data; clean and de-duplicate; explore; select features by mutual information; split by time (last 20% held out); train Random Forest and XGBoost; compare MAE, MSE, RMSE, R² and category metrics; save the best with Joblib; serve through the API."],
  ["System architecture", "React (Vite) frontend → REST API (FastAPI) → MySQL for observations, predictions, alerts and recommendations; the API loads the saved Joblib model and SHAP explainer from the ml folder."],
  ["Technology stack", "React, Chart.js, Leaflet; Python, FastAPI, SQLAlchemy, MySQL; pandas, NumPy, scikit-learn, XGBoost, SHAP, Matplotlib, ReportLab."],
  ["Machine learning algorithms", "Random Forest regressor (also gives a tree-spread uncertainty range) and XGBoost regressor; the lowest test RMSE wins."],
  ["Expected outcomes", "A working AQI monitor and forecaster with explainable results, hotspot identification and actionable, clearly labelled suggestions."],
  ["Future scope", "Live OpenAQ/CPCB and Open-Meteo ingestion, IoT sensors, satellite data, LSTM models, user authentication, external alert delivery (SMS/email) and a QSVM comparison."],
];
export default function About() {
  return (
    <section>
      <h2 className="page-title">About Project</h2>
      <p className="muted">Air Quality Prediction and Urban Pollution Mitigation System</p>
      <div className="grid">{S.map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div>
    </section>
  );
}
