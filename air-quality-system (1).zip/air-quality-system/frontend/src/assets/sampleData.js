// SIMULATED demonstration data. Deterministic (no random numbers) and always
// shown in the UI with a "Sample data" label. It is NEVER live measurement.
// Replaced by the backend (/api/dashboard) once MySQL + dataset are connected.
import { computeAqi } from "../services/aqi.js";

export const SAMPLE_LOCATIONS = ["Sample Station A", "Sample Station B", "Sample Station C"];
const SCALE = { "Sample Station A": 1.0, "Sample Station B": 1.5, "Sample Station C": 0.7 };

function reading(base, hour, day = 0) {
  const rush = Math.exp(-((hour - 9) ** 2) / 8) + Math.exp(-((hour - 19) ** 2) / 8);
  const f = base * (1 + 0.25 * rush + 0.12 * Math.sin((day * 5 + hour) / 3));
  return {
    pm25: +(62 * f).toFixed(1), pm10: +(118 * f).toFixed(1), co: +(1.1 * f).toFixed(2),
    no2: +(38 * f).toFixed(1), so2: +(14 * f).toFixed(1), o3: +(44 * f).toFixed(1),
  };
}

export function getSample(location) {
  const base = SCALE[location] ?? 1;
  const now = new Date();
  const trend = Array.from({ length: 24 }, (_, h) => {
    const r = reading(base, h);
    return { label: `${String(h).padStart(2, "0")}:00`, ...r, aqi: computeAqi(r).aqi };
  });
  const weekly = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d, i) => ({
    label: d, aqi: computeAqi(reading(base, 12, i + 1)).aqi,
  }));
  return {
    location,
    simulated: true,
    source: "Sample dataset (simulated, not live)",
    updatedAt: now.toISOString(),
    current: reading(base, now.getHours()),
    weather: { temperature: +(27 + 4 * base).toFixed(1), humidity: Math.round(58 + 6 * base), windSpeed: +(9 - 2 * base).toFixed(1), condition: "Partly cloudy" },
    trend,
    weekly,
  };
}
