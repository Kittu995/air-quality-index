import { Routes, Route } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import Home from "./pages/Home.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Predict from "./pages/Predict.jsx";
import HotspotMap from "./pages/HotspotMap.jsx";
import Analytics from "./pages/Analytics.jsx";
import Alerts from "./pages/Alerts.jsx";
import Mitigation from "./pages/Mitigation.jsx";
import History from "./pages/History.jsx";
import Reports from "./pages/Reports.jsx";
import About from "./pages/About.jsx";
import Placeholder from "./pages/Placeholder.jsx";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="predict" element={<Predict />} />
        <Route path="map" element={<HotspotMap />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="alerts" element={<Alerts />} />
        <Route path="mitigation" element={<Mitigation />} />
        <Route path="history" element={<History />} />
        <Route path="reports" element={<Reports />} />
        <Route path="about" element={<About />} />
        <Route path="*" element={<Placeholder title="Page not found" step="Use the sidebar to continue" />} />
      </Route>
    </Routes>
  );
}
