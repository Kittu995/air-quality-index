import { useEffect, useState } from "react";
import { api } from "../services/api.js";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { SAMPLE_LOCATIONS } from "../assets/sampleData.js";

const NAV = [
  ["/", "Home"], ["/dashboard", "Dashboard"], ["/predict", "AQI Prediction"],
  ["/map", "Pollution Hotspot Map"], ["/analytics", "Air Quality Analytics"],
  ["/alerts", "Pollution Alerts"], ["/mitigation", "Mitigation Recommendations"],
  ["/history", "Historical Data"], ["/reports", "Reports"], ["/about", "About Project"],
];

export default function Layout() {
  const [open, setOpen] = useState(false);
  const [locations, setLocations] = useState(SAMPLE_LOCATIONS);
  const [location, setLocation] = useState(SAMPLE_LOCATIONS[0]);
  useEffect(() => {
    api("/api/locations").then((l) => { if (l.length) { setLocations(l.map((x) => x.name)); setLocation(l[0].name); } }).catch(() => {});
  }, []);
  const navigate = useNavigate();

  return (
    <div className="shell">
      <aside className={`sidebar ${open ? "open" : ""}`} aria-label="Main navigation">
        <div className="brand">
          <svg width="32" height="32" viewBox="0 0 32 32" aria-hidden="true">
            <circle cx="16" cy="16" r="15" fill="#13a87b" />
            <path d="M7 19c3-1 4-5 9-5s6 4 9 5M9 23c3-1 4-3 7-3s4 2 7 3" stroke="#0b2545" strokeWidth="2.2" fill="none" strokeLinecap="round" />
          </svg>
          <span>AirSense</span>
        </div>
        <nav>
          {NAV.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"} onClick={() => setOpen(false)}>{label}</NavLink>
          ))}
        </nav>
      </aside>

      <div className="main">
        <header className="topbar">
          <button className="icon-btn menu-btn" onClick={() => setOpen(!open)} aria-label="Toggle navigation">☰</button>
          <h1 className="app-title">Air Quality Prediction and Urban Pollution Mitigation System</h1>
          <label className="loc">
            <span className="sr">Location</span>
            <select value={location} onChange={(e) => setLocation(e.target.value)}>
              {locations.map((l) => <option key={l}>{l}</option>)}
            </select>
          </label>
          <button className="icon-btn" onClick={() => navigate("/alerts")} aria-label="Open pollution alerts">🔔</button>
          <div className="profile" title="Authentication is added in a later step">
            <span className="avatar">G</span><span className="pname">Guest</span>
          </div>
        </header>
        <main className="content"><Outlet context={{ location, locations }} /></main>
      </div>
    </div>
  );
}
