export const Loading = ({ text = "Loading air quality data…" }) => (
  <div className="state" role="status"><span className="spinner" />{text}</div>
);
export const ErrorBox = ({ message, onRetry }) => (
  <div className="state error" role="alert">
    <strong>Could not load data.</strong> {message}
    {onRetry && <button className="btn small" onClick={onRetry}>Try again</button>}
  </div>
);
export const Empty = ({ title, hint }) => (
  <div className="state"><strong>{title}</strong><span>{hint}</span></div>
);
