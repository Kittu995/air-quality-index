import { Line, Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement,
  BarElement, ArcElement, Tooltip, Legend, Filler,
} from "chart.js";
import { categoryFor, POLLUTANTS } from "../services/aqi.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Tooltip, Legend, Filler);
ChartJS.defaults.font.family = "Figtree, system-ui, sans-serif";
ChartJS.defaults.color = "#47606f";

const opts = { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } };

export const AqiTrend = ({ trend }) => (
  <Line options={{ ...opts, plugins: { legend: { display: false } } }} data={{
    labels: trend.map((h) => h.label),
    datasets: [{ label: "AQI", data: trend.map((h) => h.aqi), borderColor: "#1d6fa5", backgroundColor: "rgba(29,111,165,.12)", fill: true, tension: 0.35, pointRadius: 0 }],
  }} />
);

export const PmCompare = ({ trend }) => {
  const rows = trend.filter((_, i) => i % 3 === 0);
  return (
    <Bar options={opts} data={{
      labels: rows.map((h) => h.label),
      datasets: [
        { label: "PM2.5 (µg/m³)", data: rows.map((h) => h.pm25), backgroundColor: "#13a87b", borderRadius: 4 },
        { label: "PM10 (µg/m³)", data: rows.map((h) => h.pm10), backgroundColor: "#0b2545", borderRadius: 4 },
      ],
    }} />
  );
};

// Share of each pollutant's CPCB sub-index (units differ, so raw values are not comparable).
export const Distribution = ({ subIndices }) => {
  const rows = POLLUTANTS.filter((p) => subIndices[p.key] != null);
  return (
    <Doughnut options={{ ...opts, cutout: "62%" }} data={{
      labels: rows.map((p) => p.label),
      datasets: [{ data: rows.map((p) => subIndices[p.key]), backgroundColor: ["#13a87b", "#0b2545", "#1d6fa5", "#7cc6b0", "#9bb6c9", "#f2b035"], borderWidth: 0 }],
    }} />
  );
};

export const Weekly = ({ weekly }) => (
  <Bar options={{ ...opts, plugins: { legend: { display: false } } }} data={{
    labels: weekly.map((d) => d.label),
    datasets: [{ label: "AQI", data: weekly.map((d) => d.aqi), backgroundColor: weekly.map((d) => categoryFor(d.aqi).color), borderRadius: 6 }],
  }} />
);
