CREATE DATABASE IF NOT EXISTS air_quality CHARACTER SET utf8mb4;
USE air_quality;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) DEFAULT 'viewer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE locations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  latitude DOUBLE NOT NULL,
  longitude DOUBLE NOT NULL,
  is_simulated BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE air_quality_records (  -- observations only, never predictions
  id INT AUTO_INCREMENT PRIMARY KEY,
  location_id INT NOT NULL,
  recorded_at DATETIME NOT NULL,
  pm25 DOUBLE, pm10 DOUBLE, co DOUBLE, no2 DOUBLE, so2 DOUBLE, o3 DOUBLE,
  traffic_density DOUBLE,
  aqi INT,
  dominant_pollutant VARCHAR(10),
  source VARCHAR(120) NOT NULL,
  is_simulated BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
  INDEX ix_aq_loc_time (location_id, recorded_at)
);
CREATE TABLE weather_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  location_id INT NOT NULL,
  recorded_at DATETIME NOT NULL,
  temperature DOUBLE, humidity DOUBLE, wind_speed DOUBLE,
  source VARCHAR(120) NOT NULL,
  is_simulated BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE,
  INDEX ix_w_loc_time (location_id, recorded_at)
);
CREATE TABLE aqi_predictions (       -- model output, kept apart from observations
  id INT AUTO_INCREMENT PRIMARY KEY,
  location_id INT NULL,
  user_id INT NULL,
  input_json TEXT NOT NULL,
  predicted_aqi INT NOT NULL,
  current_aqi INT,
  category VARCHAR(20),
  model_name VARCHAR(40),
  uncertainty_low INT, uncertainty_high INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE SET NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE pollution_alerts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  location_id INT NOT NULL,
  aqi INT NOT NULL,
  category VARCHAR(20) NOT NULL,
  message TEXT NOT NULL,
  record_time DATETIME NOT NULL,
  is_simulated BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE
);
CREATE TABLE mitigation_recommendations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  location_id INT NOT NULL,
  issue VARCHAR(150) NOT NULL,
  action TEXT NOT NULL,
  priority VARCHAR(10) NOT NULL,
  expected_benefit TEXT,
  origin VARCHAR(60) DEFAULT 'AI-generated suggestion (not verified)',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (location_id) REFERENCES locations(id) ON DELETE CASCADE
);
